My submission for GT CS 2110 HW 08

A simple game where the player controls zero suit samus using the arrow keys.
A jigglypuff will constantly be chasing you.
Shoot using the A (z) button.
Kill 5 Jigglypuff before 4 run into you and you win, or else you lose.