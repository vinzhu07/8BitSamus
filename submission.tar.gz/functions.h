#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include "main.h"

gameState setUpGame(gameState state);
gameState process(gameState state, u32 current, u32 previous);
gameState update(gameState *state);





#endif