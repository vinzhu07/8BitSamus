/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x40 samus samus.png 
 * Time-stamp: Sunday 04/04/2021, 17:33:50
 * 
 * Image Information
 * -----------------
 * samus.png 30@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SAMUS_H
#define SAMUS_H

extern const unsigned short samus[1200];
#define SAMUS_SIZE 2400
#define SAMUS_LENGTH 1200
#define SAMUS_WIDTH 30
#define SAMUS_HEIGHT 40

#endif

