/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=7x2 blastleft blastleft.png 
 * Time-stamp: Sunday 04/04/2021, 20:24:10
 * 
 * Image Information
 * -----------------
 * blastleft.png 7@2
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#include "blastleft.h"

const unsigned short blastleft[14] =
{
	0x35cd,0x4e73,0x5af6,0x5f37,0x6379,0x639b,0x639c,0x35ed,0x52b4,0x5b16,0x5b17,0x5b38,0x5b59,0x5f39
};

