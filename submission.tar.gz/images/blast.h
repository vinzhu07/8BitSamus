/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=7x2 blast blast.png 
 * Time-stamp: Sunday 04/04/2021, 20:19:55
 * 
 * Image Information
 * -----------------
 * blast.png 7@2
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLAST_H
#define BLAST_H

extern const unsigned short blast[14];
#define BLAST_SIZE 28
#define BLAST_LENGTH 14
#define BLAST_WIDTH 7
#define BLAST_HEIGHT 2

#endif

