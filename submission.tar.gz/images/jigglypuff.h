/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=23x26 jigglypuff jigglypuff.png 
 * Time-stamp: Sunday 04/04/2021, 20:03:57
 * 
 * Image Information
 * -----------------
 * jigglypuff.png 23@26
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef JIGGLYPUFF_H
#define JIGGLYPUFF_H

extern const unsigned short jigglypuff[598];
#define JIGGLYPUFF_SIZE 1196
#define JIGGLYPUFF_LENGTH 598
#define JIGGLYPUFF_WIDTH 23
#define JIGGLYPUFF_HEIGHT 26

#endif

