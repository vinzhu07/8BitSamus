/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=7x2 blast blast.png 
 * Time-stamp: Sunday 04/04/2021, 20:19:55
 * 
 * Image Information
 * -----------------
 * blast.png 7@2
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#include "blast.h"

const unsigned short blast[14] =
{
	0x639c,0x639b,0x6379,0x5f37,0x5af6,0x4e73,0x35cd,0x5f39,0x5b59,0x5b38,0x5b17,0x5b16,0x52b4,0x35ed
};

