/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x40 samusleft samusleft.png 
 * Time-stamp: Sunday 04/04/2021, 17:33:37
 * 
 * Image Information
 * -----------------
 * samusleft.png 30@40
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SAMUSLEFT_H
#define SAMUSLEFT_H

extern const unsigned short samusleft[1200];
#define SAMUSLEFT_SIZE 2400
#define SAMUSLEFT_LENGTH 1200
#define SAMUSLEFT_WIDTH 30
#define SAMUSLEFT_HEIGHT 40

#endif

