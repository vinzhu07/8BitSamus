/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=7x2 blastleft blastleft.png 
 * Time-stamp: Sunday 04/04/2021, 20:24:10
 * 
 * Image Information
 * -----------------
 * blastleft.png 7@2
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLASTLEFT_H
#define BLASTLEFT_H

extern const unsigned short blastleft[14];
#define BLASTLEFT_SIZE 28
#define BLASTLEFT_LENGTH 14
#define BLASTLEFT_WIDTH 7
#define BLASTLEFT_HEIGHT 2

#endif

